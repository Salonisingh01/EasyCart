//
//  ScrollViewController.swift
//  EasyCart
//
//  Created by WCTM 07 on 08/11/24.
//

import UIKit

class ScrollViewController: UIViewController, UICollectionViewDataSource , UICollectionViewDelegate{
    
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var currentCellIndex = 0
    
    var quotes = ["time","list","img"]
    
    var timer : Timer?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        timer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(slideToNext), userInfo: nil, repeats: true)
    
    }
    

    @objc func slideToNext(){
        if currentCellIndex < quotes.count - 1 {
            currentCellIndex += 1
        }
        else{
            currentCellIndex = 0
        }
         
        collectionView.scrollToItem(at: IndexPath(item : currentCellIndex , section: 0 ), at: .right, animated: true)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return quotes.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell8", for: indexPath) as! MyCollectionView
        cell.myimage.image = UIImage(named: quotes[indexPath.row])
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, layout   collectionViewLayout: UICollectionViewLayout , sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        
        return CGSize(width: collectionView.frame.width, height: 234 )
    }
    
      
}


 
