//
//  ProfileViewController.swift
//  EasyCart
//
//  Created by WCTM 07 on 24/10/24.
//

import UIKit
import FirebaseCore
import FirebaseDatabase

class ProfileViewController: UIViewController {
    
    
    @IBOutlet weak var Label: UILabel!
    var name = " "

    
    override func viewDidLoad() {
        super.viewDidLoad()
        Label.text = name
        
    }
    
    @IBAction func List(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MainPageViewController") as! MainPageViewController
        self.navigationController?.pushViewController(vc, animated: true)

    }
    
    
    @IBAction func signOut(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginPageViewController") as! LoginPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func help(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "feedbackViewController") as! feedbackViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}


