//
//  LoginPageViewController.swift
//  EasyCart
//
//  Created by WCTM 10 on 15/10/24.
//

import UIKit
import FirebaseCore
import FirebaseDatabase

class LoginPageViewController: UIViewController {

    @IBOutlet weak var userName: UITextField!

    @IBOutlet weak var password: UITextField!
    
    var UserN = [String]()
    var Pass = [String]()
    
    var ref: DatabaseReference?
    var databasehandle : DatabaseHandle?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
        databasehandle = ref?.child("userAuth").observe(.childAdded, with: {(snapshot) in
            let validID = snapshot.value as? String
            if let actualId = validID {
                 self.UserN.append(actualId)
            }
                let vaildPass = snapshot.value as? String
                if let actualPass = vaildPass{
                    self.Pass.append(actualPass)
            }
        })
    }
    

    @IBAction func Login(_ sender: UIButton) {
        if(userName.text != "" && password.text != ""){
            let limitset = UserN.count - 1
           
            if limitset >= 0 {
            for i in 0...limitset{
                if(userName.text == UserN[i]){
                    if(password.text == Pass[i]){
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MainPageViewController") as! MainPageViewController
                        self.navigationController?.pushViewController(vc, animated: true)
                    }}
               }
            }
        }
        
   }
    
}
