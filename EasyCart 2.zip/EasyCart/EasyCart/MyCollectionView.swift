//
//  MyCollectionView.swift
//  EasyCart
//
//  Created by WCTM 07 on 08/11/24.
//

import UIKit

class MyCollectionView: UICollectionViewCell {
    
    
    @IBOutlet weak var myimage: UIImageView!
    
}
