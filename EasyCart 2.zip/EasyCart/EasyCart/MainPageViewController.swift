//
//  MainPageViewController.swift
//  EasyCart
//
//  Created by WCTM 10 on 15/10/24.
//

import UIKit
import FirebaseCore
import FirebaseDatabase

class MainPageViewController: UIViewController ,UITableViewDelegate , UITableViewDataSource {
   
  
       @IBOutlet weak var addView: UIView!
        @IBOutlet weak var table: UITableView!
        @IBOutlet weak var Name: UITextField!
        @IBOutlet weak var content: UITextField!
        
        var ref: DatabaseReference!
        var databaseHandle: DatabaseHandle?
        var postData = [String]()
        var myindex = 0
//        var cNameText: UITextField? //shows alert

        override func viewDidLoad() {
            super.viewDidLoad()
            addView.isHidden = true
      
            ref = Database.database().reference()
            
            databaseHandle = ref.child("List_name").observe(.childAdded, with: { snapshot in
                if let post = snapshot.value as? String {
                    self.postData.append(post)
                    self.table.reloadData()
                }
    
            })

            
            databaseHandle = ref.child("List_name").observe(.childRemoved, with: { snapshot in
                        if let post = snapshot.value as? String {
                            if let index = self.postData.firstIndex(of: post) {
                                self.postData.remove(at: index)
                                self.table.reloadData()
                            }
                        }
                    })
                }

                func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
                    return postData.count
                }

                func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                    let cell = table.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
                    cell.textLabel?.text = postData[indexPath.row]
                    return cell
                }
    
    //editing of table:------
    
    

    func tableView(_ tableView: UITableView , editingStyleForRowAt indexPath : IndexPath) -> UITableViewCell.EditingStyle{
        return .delete
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            tableView.beginUpdates()
            postData.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with:.fade)
            tableView.endUpdates()
        }
    }
    
    
    
    
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myindex = indexPath.row
        
        
//        let listSelected = postData[indexPath.row]
//        let  meassage = UIAlertController(title: "Edit Operation ", message: "Edit list Name ", preferredStyle: .alert)
//        
//        let update = UIAlertAction(title: "Update", style: .default) { (action) in
//            
//            let updatedName = self.cNameText?.text!
//            self.postData[indexPath.row] = updatedName!
//            DispatchQueue.main.async{
//                self.table.reloadData()
//                print("Data has been update in table.")
//            }
//            
//            
//        }
//        let cancel = UIAlertAction(title:" cancel", style: .cancel) { (action) in
//            print("Edit Operation canceled ")
//        }
//        
//        meassage.addAction(update)
//        meassage.addAction(cancel)
//        meassage.addTextField { (textField) in
//            self.cNameText = textField
//            self.cNameText?.placeholder = "Update List Name "
//            self.cNameText?.text = listSelected
//        }
//        
//        self.present(meassage, animated: true , completion: nil )
//        
        
        if(myindex == 0){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ListDetailViewController") as! ListDetailViewController
            self.navigationController?.pushViewController(vc, animated: true)
         
        }
        if(myindex == 1){
            let vc1 = self.storyboard?.instantiateViewController(withIdentifier: "list1ViewController") as! list1ViewController
            self.navigationController?.pushViewController(vc1, animated: true)
            
        }
        if(myindex == 2){
            let vc2 = self.storyboard?.instantiateViewController(withIdentifier: "list2ViewController") as! list2ViewController
            self.navigationController?.pushViewController(vc2, animated: true)
            
        }
        if(myindex == 3){
            let vc3 = self.storyboard?.instantiateViewController(withIdentifier: "list3ViewController") as! list3ViewController
            self.navigationController?.pushViewController(vc3, animated: true)
            
        }
    }

         
                @IBAction func addNote(_ sender: UIButton) {
                    table.isHidden.toggle()
                    addView.isHidden.toggle()

                }

                @IBAction func add(_ sender: UIButton) {
                    guard let nameText = Name.text, !nameText.isEmpty,
                          let contentText = content.text, !contentText.isEmpty else {
                        // Optionally show an alert to the user
                        return
                    }
                            
                            table.isHidden = false
                            addView.isHidden = true
                    self.ref.child("List_name").child(Name.text!).setValue(content.text)
                            
                            // Clear text fields
                            Name.text = ""
                            content.text = ""
                        }
    
    
    
    
    @IBAction func Profile(_ sender: UIButton) {
        
        let vc4 = self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController
        self.navigationController?.pushViewController(vc4, animated: true)
    }
    
    
    @IBAction func Lists(_ sender: UIButton) {
        let vc5 = self.storyboard?.instantiateViewController(withIdentifier: "MainPageViewController") as! MainPageViewController
        self.navigationController?.pushViewController(vc5 , animated: true)
    }
    
    
                    }

