//
//  feedbackViewController.swift
//  EasyCart
//
//  Created by WCTM 07 on 04/11/24.
//

import UIKit

class feedbackViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    

    @IBAction func listbar(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MainPageViewController") as! MainPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
    @IBAction func profilepage(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    

    @IBAction func Submit(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "submissionPageViewController") as! submissionPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    

}
