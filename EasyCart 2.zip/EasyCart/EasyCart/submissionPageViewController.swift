//
//  submissionPageViewController.swift
//  EasyCart
//
//  Created by WCTM 07 on 05/11/24.
//

import UIKit

class submissionPageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    @IBAction func Listpage(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MainPageViewController") as! MainPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func profilePage(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
