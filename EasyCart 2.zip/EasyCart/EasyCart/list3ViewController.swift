//
//  list3ViewController.swift
//  EasyCart
//
//  Created by WCTM 07 on 04/11/24.
//

import UIKit
import FirebaseCore
import FirebaseDatabase

class list3ViewController: UIViewController , UITableViewDelegate , UITableViewDataSource {

    
    @IBOutlet weak var Table3: UITableView!
    
    @IBOutlet weak var itemNumber3: UITextField!
    
    @IBOutlet weak var itemName3: UITextField!
    
    @IBOutlet weak var addViiew3: UIView!
    
    var ref: DatabaseReference!
    var databaseHandle: DatabaseHandle?
    var postData = [String]()
    
    var myindex = 0
    var cNameText: UITextField?
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addViiew3.isHidden = true
  
        ref = Database.database().reference()
        
        databaseHandle = ref.child("list4_item").observe(.childAdded, with: { snapshot in
            if let post = snapshot.value as? String {
                self.postData.append(post)
                self.Table3.reloadData()
    }
        })
        databaseHandle = ref.child("list4_item").observe(.childRemoved, with: { snapshot in
                    if let post = snapshot.value as? String {
                        if let index = self.postData.firstIndex(of: post) {
                            self.postData.remove(at: index)
                            self.Table3.reloadData()
                        }
                    }
                })


    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postData.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Table3.dequeueReusableCell(withIdentifier: "cell5", for: indexPath)
        cell.textLabel?.text = postData[indexPath.row]
        return cell
    }

    
    func tableView(_ tableView: UITableView , editingStyleForRowAt indexPath : IndexPath) -> UITableViewCell.EditingStyle{
        return .delete
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            tableView.beginUpdates()
            postData.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with:.fade)
            tableView.endUpdates()
        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myindex = indexPath.row
        
        
        let listSelected = postData[indexPath.row]
        let  meassage = UIAlertController(title: "Edit Operation ", message: "Edit list Name ", preferredStyle: .alert)
        
        let update = UIAlertAction(title: "Update", style: .default) { (action) in
            
            let updatedName = self.cNameText?.text!
            self.postData[indexPath.row] = updatedName!
            DispatchQueue.main.async{
                self.Table3.reloadData()
                print("Data has been update in table.")
            }
            
            
        }
        let cancel = UIAlertAction(title:" cancel", style: .cancel) { (action) in
            print("Edit Operation canceled ")
        }
        
        meassage.addAction(update)
        meassage.addAction(cancel)
        meassage.addTextField { (textField) in
            self.cNameText = textField
            self.cNameText?.placeholder = "Update List Name "
            self.cNameText?.text = listSelected
        }
        
        self.present(meassage, animated: true , completion: nil )
    }
   
    
    @IBAction func addItems4(_ sender: UIButton) {
        guard let nameText = itemName3.text, !nameText.isEmpty,
              let contentText = itemNumber3.text, !contentText.isEmpty else {
            // Optionally show an alert to the user
            return
        }
                
                Table3.isHidden = false
                addViiew3.isHidden = true
        self.ref.child("list4_item").child(itemNumber3.text!).setValue(itemName3.text)
                
                // Clear text fields
        itemNumber3.text = ""
        itemName3.text = ""
    }
    
    
    @IBAction func Showww(_ sender: UIButton) {
        
        Table3.isHidden.toggle()
        addViiew3.isHidden.toggle()
    }
    
}
