//
//  list1ViewController.swift
//  EasyCart
//
//  Created by WCTM 07 on 04/11/24.
//

import UIKit
import FirebaseCore
import FirebaseDatabase

class list1ViewController: UIViewController , UITableViewDelegate , UITableViewDataSource{
    
    

    @IBOutlet weak var Table1: UITableView!
    
    @IBOutlet weak var itemOrder: UITextField!
    @IBOutlet weak var addViiew: UIView!
    
    @IBOutlet weak var itemName: UITextField!
    
    var ref: DatabaseReference!
    var databaseHandle: DatabaseHandle?
    var postData = [String]()
    var myindex = 0
    var cNameText: UITextField?
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
   
        addViiew.isHidden = true
  
        ref = Database.database().reference()
        
        databaseHandle = ref.child("list2_item").observe(.childAdded, with: { snapshot in
            if let post = snapshot.value as? String {
                self.postData.append(post)
                self.Table1.reloadData()
    }
        })
        databaseHandle = ref.child("list2_item").observe(.childRemoved, with: { snapshot in
                    if let post = snapshot.value as? String {
                        if let index = self.postData.firstIndex(of: post) {
                            self.postData.remove(at: index)
                            self.Table1.reloadData()
                        }
                    }
                })
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postData.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Table1.dequeueReusableCell(withIdentifier: "cell3", for: indexPath)
        cell.textLabel?.text = postData[indexPath.row]
        return cell
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return ""
        
    }
    func tableView(_ tableView: UITableView , editingStyleForRowAt indexPath : IndexPath) -> UITableViewCell.EditingStyle{
        return .delete
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            tableView.beginUpdates()
            postData.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with:.fade)
            tableView.endUpdates()
        }
    }
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myindex = indexPath.row
        
        
        let listSelected = postData[indexPath.row]
        let  meassage = UIAlertController(title: "Edit Operation ", message: "Edit list Name ", preferredStyle: .alert)
        
        let update = UIAlertAction(title: "Update", style: .default) { (action) in
            
            let updatedName = self.cNameText?.text!
            self.postData[indexPath.row] = updatedName!
            DispatchQueue.main.async{
                self.Table1.reloadData()
                print("Data has been update in table.")
            }
            
            
        }
        let cancel = UIAlertAction(title:" cancel", style: .cancel) { (action) in
            print("Edit Operation canceled ")
        }
        
        meassage.addAction(update)
        meassage.addAction(cancel)
        meassage.addTextField { (textField) in
            self.cNameText = textField
            self.cNameText?.placeholder = "Update List Name "
            self.cNameText?.text = listSelected
        }
        
        self.present(meassage, animated: true , completion: nil )
    }

    @IBAction func additems1(_ sender: UIButton) {
        guard let nameText = itemOrder.text, !nameText.isEmpty,
              let contentText = itemName.text, !contentText.isEmpty else {
            // Optionally show an alert to the user
            return
        }
                
                Table1.isHidden = false
                addViiew.isHidden = true
        self.ref.child("list2_item").child(itemOrder.text!).setValue(itemName.text)
                
                // Clear text fields
        itemOrder.text = ""
        itemName.text = ""
    }
    
    
    
    
    @IBAction func show(_ sender: UIButton) {
        Table1.isHidden.toggle()
        addViiew.isHidden.toggle()
    }
    
    
    
    
    

}
