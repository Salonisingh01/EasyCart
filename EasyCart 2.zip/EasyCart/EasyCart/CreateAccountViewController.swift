//
//  CreateAccountViewController.swift
//  EasyCart
//
//  Created by WCTM 10 on 15/10/24.
//

import UIKit
import FirebaseCore
import FirebaseDatabase

class CreateAccountViewController: UIViewController {

    @IBOutlet weak var Email: UITextField!
    
    @IBOutlet weak var UserName: UITextField!
    
    @IBOutlet weak var Password: UITextField!
    
    var ref = Database.database().reference()

    override func viewDidLoad() {
        super.viewDidLoad()
   
    }
    

    @IBAction func createAccount(_ sender: UIButton) {
        if(Email.text != "" && UserName.text != "" && Password.text != ""){
            self.ref.child(" Customer Details").child(UserName.text!).setValue(["Email" : Email.text , "UserName" : UserName.text, "Password" : Password.text])
            
            let v = self.storyboard?.instantiateViewController(withIdentifier: "MainPageViewController") as! MainPageViewController
            v.self.navigationController?.pushViewController(v, animated: true)
           
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController
            
            let id = UserName.text
            vc.name += id!
           
            
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }

}
