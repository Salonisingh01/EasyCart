//
//  FirstPageViewController.swift
//  EasyCart
//
//  Created by WCTM 10 on 15/10/24.
//

import UIKit

class FirstPageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func emailPage(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginPageViewController") as! LoginPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func signupPage(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "CreateAccountViewController") as! CreateAccountViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
   
}
