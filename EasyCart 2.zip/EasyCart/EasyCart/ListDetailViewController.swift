//
//  ListDetailViewController.swift
//  EasyCart
//
//  Created by WCTM 07 on 21/10/24.
//

import UIKit
import FirebaseCore
import FirebaseDatabase

class ListDetailViewController: UIViewController,UITableViewDelegate , UITableViewDataSource {

    
    @IBOutlet weak var table: UITableView!
    
    @IBOutlet weak var addView: UIView!
    
    @IBOutlet weak var content2: UITextField!
    

    @IBOutlet weak var name2: UITextField!
    
    var ref: DatabaseReference!
    var databaseHandle: DatabaseHandle?
    var postData = [String]()
    var myindex = 0
    var cNameText: UITextField?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addView.isHidden = true
  
        ref = Database.database().reference()
        
        databaseHandle = ref.child("list1_item").observe(.childAdded, with: { snapshot in
            if let post = snapshot.value as? String {
                self.postData.append(post)
                self.table.reloadData()
    }
        })
        databaseHandle = ref.child("list1_item").observe(.childRemoved, with: { snapshot in
                    if let post = snapshot.value as? String {
                        if let index = self.postData.firstIndex(of: post) {
                            self.postData.remove(at: index)
                            self.table.reloadData()
                        }
                    }
                })
            }

            func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
                return postData.count
            }

            func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                let cell = table.dequeueReusableCell(withIdentifier: "cell2", for: indexPath)
                cell.textLabel?.text = postData[indexPath.row]
                return cell
            }
    
    func tableView(_ tableView: UITableView , editingStyleForRowAt indexPath : IndexPath) -> UITableViewCell.EditingStyle{
        return .delete
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            tableView.beginUpdates()
            postData.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with:.fade)
            tableView.endUpdates()
        }
    }
  
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myindex = indexPath.row
        
        
        let listSelected = postData[indexPath.row]
        let  meassage = UIAlertController(title: "Edit Operation ", message: "Edit list Name ", preferredStyle: .alert)
        
        let update = UIAlertAction(title: "Update", style: .default) { (action) in
            
            let updatedName = self.cNameText?.text!
            self.postData[indexPath.row] = updatedName!
            DispatchQueue.main.async{
                self.table.reloadData()
                print("Data has been update in table.")
            }
            
            
        }
        let cancel = UIAlertAction(title:" cancel", style: .cancel) { (action) in
            print("Edit Operation canceled ")
        }
        
        meassage.addAction(update)
        meassage.addAction(cancel)
        meassage.addTextField { (textField) in
            self.cNameText = textField
            self.cNameText?.placeholder = "Update List Name "
            self.cNameText?.text = listSelected
        }
        
        self.present(meassage, animated: true , completion: nil )
    }
    
    @IBAction func add(_ sender: UIButton) {
        guard let nameText = name2.text, !nameText.isEmpty,
              let contentText = content2.text, !contentText.isEmpty else {
            // Optionally show an alert to the user
            return
        }
                
                table.isHidden = false
                addView.isHidden = true
        self.ref.child("list1_item").child(content2.text!).setValue(name2.text)
                
                // Clear text fields
        name2.text = ""
        content2.text = ""
            }

    
    
    
    @IBAction func newItem(_ sender: UIButton) {
        table.isHidden.toggle()
        addView.isHidden.toggle()
    }
    
}
