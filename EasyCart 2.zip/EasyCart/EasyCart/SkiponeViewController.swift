//
//  SkiponeViewController.swift
//  EasyCart
//
//  Created by WCTM 07 on 24/10/24.
//

import UIKit

class SkiponeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    @IBAction func Start(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SkipTwoViewController") as! SkipTwoViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func skip(_ sender: UIButton) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "FirstPageViewController") as! FirstPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
}
