//
//  PageControllerViewController.swift
//  EasyCart
//
//  Created by WCTM 07 on 25/10/24.
//

import UIKit

class PageControllerViewController: UIViewController, UIScrollViewDelegate{

    @IBOutlet weak var viewWidth: NSLayoutConstraint!
    @IBOutlet weak var scroll: UIScrollView!
    
    @IBOutlet weak var page: UIPageControl!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        page.numberOfPages = 3
        page.currentPage = 0
        scroll.delegate = self
        
        viewWidth.constant = self.view.frame.width * 3
        self.view.layoutIfNeeded()
    }
    

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let item = scrollView.contentOffset.x / self.view.frame.width
        page .currentPage = Int(item)
    }

}
