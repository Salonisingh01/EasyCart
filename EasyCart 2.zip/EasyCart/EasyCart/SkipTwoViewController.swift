//
//  SkipTwoViewController.swift
//  EasyCart
//
//  Created by WCTM 07 on 24/10/24.
//

import UIKit

class SkipTwoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    @IBAction func Next(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "FirstPageViewController") as! FirstPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
